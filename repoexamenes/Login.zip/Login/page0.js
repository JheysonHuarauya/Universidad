import { firebaseConfig } from './config.js';

const firebaseApp = firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const firestore = firebase.firestore();
const signupForm = document.querySelector('.registration.form');
const loginForm = document.querySelector('.login.form');
const forgotForm = document.querySelector('.forgot.form');
const container = document.querySelector('.container');
const signupBtn = document.querySelector('.signupbtn');
const loginBtn = document.querySelector('.loginbtn');
const forgotBtn = document.querySelector('.forgotbtn');
const anchors = document.querySelectorAll('a');

anchors.forEach(anchor => {
  anchor.addEventListener('click', () => {
    const id = anchor.id;
    switch (id) {
      case 'loginLabel':
        signupForm.style.display = 'none';
        loginForm.style.display = 'block';
        forgotForm.style.display = 'none';
        break;
      case 'signupLabel':
        signupForm.style.display = 'block';
        loginForm.style.display = 'none';
        forgotForm.style.display = 'none';
        break;
      case 'forgotLabel':
        signupForm.style.display = 'none';
        loginForm.style.display = 'none';
        forgotForm.style.display = 'block';
        break;
    }
  });
});

signupBtn.addEventListener('click', async () => {
  const email = document.querySelector('#email').value.trim();
  const password = document.querySelector('#password').value;

  try {
    const userCredential = await auth.createUserWithEmailAndPassword(email, password);
    const user = userCredential.user;
    const uid = user.uid;

    await user.sendEmailVerification();

    alert('Registro exitoso. Se envió un correo electrónico de verificación. Por favor, revise su bandeja de entrada.');

    console.log('Datos de usuario guardados');
    await firestore.collection('users').doc(uid).set({
      email: email,
    });

    signupForm.style.display = 'none';
    loginForm.style.display = 'block';
    forgotForm.style.display = 'none';
  } catch (error) {
    if (error.code === 'auth/email-already-in-use') {
      alert('Error al registrarse: Este correo electrónico ya está registrado.');
    } else {
      alert('Error al registrarse: ' + error.message);
    }
  }
});

loginBtn.addEventListener('click', async () => {
  console.log('Botón de login clickeado');
  const email = document.querySelector('#inUsr').value.trim();
  const password = document.querySelector('#inPass').value;

  try {
    const userCredential = await auth.signInWithEmailAndPassword(email, password);
    const user = userCredential.user;
    if (user.emailVerified) {
      console.log('El usuario inicia sesión con un correo electrónico verificado.');
      // Redirige al usuario a la página principal después de iniciar sesión
      window.location.replace('../repoexamenes/index.html');
    } else {
      alert('Inicio de sesión exitoso.');
    }
  } catch (error) {
    alert('Error al iniciar sesión: ' + error.message);
  }
});


forgotBtn.addEventListener('click', async () => {
  const emailForReset = document.querySelector('#forgotinp').value.trim();
  if (emailForReset.length > 0) {
    try {
      await auth.sendPasswordResetEmail(emailForReset);
      alert('Correo electrónico de restablecimiento de contraseña enviado. Por favor revise su bandeja de entrada para restablecer su contraseña.');
      signupForm.style.display = 'none';
      loginForm.style.display = 'block';
      forgotForm.style.display = 'none';
    } catch (error) {
      alert('Error al enviar el correo electrónico para restablecer la contraseña: ' + error.message);
    }
  }
});
