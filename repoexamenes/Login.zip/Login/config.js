const firebaseConfig = {
    apiKey: "AIzaSyAB5SOXzCUOzB4r2NH7WdS-KyCQaf-amcc",
    authDomain: "database2024-d7236.firebaseapp.com",
    databaseURL: "https://database2024-d7236-default-rtdb.firebaseio.com",
    projectId: "database2024-d7236",
    storageBucket: "database2024-d7236.appspot.com",
    messagingSenderId: "45518532229",
    appId: "1:45518532229:web:76cb09211a2e72566983ec",
    measurementId: "G-CZDTRVKXE5"
};
export {firebaseConfig};